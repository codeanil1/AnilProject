 package com.cg.payroll.client;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
public class MainClass {
	public static void main(String[] args){
		PayrollServices services=new PayrollServicesImpl();
		int associateId=services.acceptAssociateDetails("anil", "Thakur", "anil@gmail.com", "ytp","sfdf", "12ag43h", 2000, 3000, 4588, 55888, 2587444, "icici", "icic009");
		System.out.println("Associate id: "+associateId);
		System.out.println(services.getAllAssociatesDetails());	
	}
}
