package com.cg.payroll.services;
import java.util.List;
import javax.security.auth.login.AccountNotFoundException;
import com.cg.payroll.beans.Associate;
public interface PayrollServices {
 int acceptAssociateDetails(String firstName,String lastName,String emailId,String department,
		 String designation,String panCard,int yearlyInvestmentUnder80c,int basicSalary,int epf,int companyPf,
		 int accountNumber,String bankName,String ifscCode);
  void calculateNetSalary(int associateId)throws  AccountNotFoundException;
 Associate getAssociateDetails(int associateId)throws AccountNotFoundException;
List<Associate> getAllAssociatesDetails();
 }
